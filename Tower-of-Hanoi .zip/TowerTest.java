import java.util.Scanner;

public class TowerTest{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of disks:");
        int ndisks = sc.nextInt();
        if(ndisks>0&&ndisks<7)
        {
            System.out.println("The sequence of moves involved in the Tower of Hanoi are:");
            tower(ndisks,'A','C','B');
        }
        else
        {
            System.out.println("Invalid Input");
        }
    }
    
    public static void tower(int n, char s, char d, char aux){
        if(n==1){
            System.out.println("Move disk "+n+" from peg "+s+" to peg "+d);
            return;
        }
        tower(n-1,s,aux,d);
        System.out.println("Move disk "+n+" from peg "+s+" to peg "+d);
        tower(n-1,aux,d,s);
    }
    
}