import java.util.Scanner;

class ReverseDriver{
    public static String reverseString(String str){
       if(str==null || str.length()<=1)
       {
           return str;
       }
       return reverseString(str.substring(1))+str.charAt(0);
    }
    
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the String: ");
        String str = sc.nextLine();
        System.out.print("Reversed string is: "+reverseString(str));
    }
}