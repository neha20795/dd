import java.util.Scanner;
class Node{
    int value;
    Node next;
    public Node(int value){
        this.value  = value;
        next = null;
    }
}

public class StackDriver{
    
    static Node head = null, current;
    static int n, i=0, data=1;
    static Scanner sc = new Scanner(System.in);
    static StackDriver sd = new StackDriver();
    
    static int createStack(){
        current = head;
        if(i==0)
            return 0;
        else{
            Node newNode = new Node(data);
            data++;
            if(head == null){
                head = newNode;
            }
            else
            {
                while(current.next != null)
                    current = current.next;
                current.next = newNode;
            }
        }
        i--;
        sd.createStack();
        return 0;
    }
    static void displayStack(){
        Node temp = head;
        while(temp != null){
            System.out.print(temp.value+" ");
            temp = temp.next;
        }
    }
    static void stackReverse(){
        Node preNode = null;
        Node nextNode;
        Node cuurrent = head;
        while(current != null ){
            nextNode = current.next;
            current.next = preNode;
            preNode = current;
            current = nextNode;
        }
        head = preNode;
    }
    public static void main (String[] args) {
        System.out.print("Enter Length of List: ");
        n=sc.nextInt();
        if(n>0){
            i=n;
            int res = sd.createStack();
            System.out.println("Elements in Stack");
            sd.displayStack();
            sd.stackReverse();
            System.out.println("\nElements in the stack after reversal");
            sd.displayStack();
        }
        else{
            System.out.println("Invalid Length");
        }
    }
}





















