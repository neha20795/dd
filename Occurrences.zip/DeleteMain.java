import java.util.Scanner;
class Node{
    int data;
    Node next;
    public Node(int data){
        this.data = data;
        next = null;
    }
}
public class DeleteMain{
    static Node head = null;
    static Scanner sc = new Scanner(System.in);
    
    public static void insert(int data){
        Node current = head;
        Node newNode = new Node(data);
        if(head==null){
            head = newNode;
        }
        else{
            newNode.next = null;
            while(current.next!=null)
                current = current.next;
            
                current.next = newNode;
    
        }
    }
    
    public static void delete(int temp){
        Node current = head, net = head;
        while(current!=null){
            if(head.data == temp){
                head = head.next;
            }
            else if(current.data == temp){
                net.next = current.next;;
                current= current.next;
                continue;
            }
            net = current;
            current = current.next;
        }
    }
    
    public static void display(){
        Node current= head;
        while(current!=null){
            System.out.print(current.data+" ");
            current = current.next;
        }
    }
    
    public static void main (String[] args) {
        int n= sc.nextInt();
        if(n<=0){
            return;
        }
        for (int i=0;i<n ;i++ ){
            int temp = sc.nextInt();
            insert(temp);
        } 
        //display();
        System.out.print("Enter the element to be deleted: ");
        int tep = sc.nextInt();
        delete(tep);
        System.out.print("The list after deletion: ");
        display();
    }
}