import java.util.Scanner;
public class ScoreCardDriver{
    static int a[]={};
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the score card:");
        int n = sc.nextInt();
        if(n>0&&n<=100){
            a=new int[n];
            for (int i=0;i<n ;i++){
                System.out.print("Enter the hurdle race score "+(i+1)+":");
                a[i] = sc.nextInt();
            }
            int j= n-5;
            System.out.print("Latest hurdle race scores are: ");
            for(;j<n;j++){
                System.out.print(a[j]+" ");
            }
        }
        else{
            System.out.println("Invalid score card size");
        }
    }
}