import java.util.Scanner;

class BinarySearch{
    public static int binarySearch(int []ar, int size, int key)
    {
        int f=0,l=size-1;
        while(f<=l){
            int mid = (f+l)/2;
            if(key==ar[mid])
                return mid;
            else if(ar[mid]>key)
                l=mid-1;
            else
                f=mid+1;
        }
        return -1;
    }
    
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of Teams:");
        int n = sc.nextInt();
        if(n<=0){
            return;
        }
        int a[] = new int[n];
        System.out.println("Enter the score:");
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
        }
        System.out.println("Enter the score to be searched:");
        int key = sc.nextInt();
        int res=binarySearch(a,n,key);
        if(res == -1){
            System.out.println("Score Not Found");
        }
        else{
            System.out.print(key+" is the score of Team "+(res+1));
        }
    }
}