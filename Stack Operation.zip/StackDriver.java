import java.util.Scanner;
public class StackDriver{
    static int a[]={};
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements to be pushed in the stack:");
        int n = sc.nextInt();
        if(n>0)
        {
            a= new int[n];
            for (int i=0;i<n ;i++ )
            {
                System.out.println("Enter the element "+(i+1)+":");
                int temp = sc.nextInt();
                if(temp>0){
                    a[i]=temp;
                }
                else{
                    System.out.println("Invalid Input"); return;
                }
            }
            System.out.println("The middle element is: "+a[(n-1)/2]);
            System.out.println("The popped element is: "+a[n-1]);
        }
        else
        {
            System.out.println("Invalid Input");
        }
    }
}