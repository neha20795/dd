import java.util.Scanner;
class Chocolate{
    private int arrChocolate [];
    private int front;
    private int rear;
    private int capacity;
    private int count;
    public void enqueue(int item){
        rear = (rear+1)%capacity;
        arrChocolate[rear] = item;
        count++;
    }
    public void dequeue(){
        front = (front + 1) % capacity;
        count--;
    }
    public void display(){
        for (int i=front;i<=rear ;i++ )
            System.out.print(arrChocolate[i]+" ");
    }
    public void chocolateCount( int noOfChocolate){
        for (int i=1;i<noOfChocolate ;i++ )
        {
            if(arrChocolate[i]%2!=0)
                dequeue();
        }
    }
    
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the no. of boxes: ");
        int noOfBoxes = sc.nextInt();
        if(noOfBoxes>0 && noOfBoxes<=10){
            Chocolate chocolate = new Chocolate();
            chocolate.arrChocolate = new int[noOfBoxes];
            chocolate.front = 0;
            chocolate.rear =-1;
            chocolate.capacity = noOfBoxes;
            chocolate.count = 0;
            for(int i=0;i<noOfBoxes;i++)
            {
                System.out.print("Enter the no. of chocolates in box "+(i+1)+": ");
                int item = sc.nextInt();
                chocolate.enqueue(item);
                if(i==0){
                    if(item==0 || item%2!=0){
                        System.out.println("Sorry!!! First box always should contain positive even no. of chocolates");
                        return;
                    }
                }
            }
            chocolate.chocolateCount(noOfBoxes);
            System.out.print("No. of chocolates in each box: ");
            chocolate.display();
        }
        else{
            System.out.println("Invalid input");
        }
    }
}