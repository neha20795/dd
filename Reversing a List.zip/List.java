import java.util.Scanner;

class Node{
    int data;
    Node next;
}

public class List{
    public static Node head = null;
    public static Node tail = null;
    
    public void append(int data){
        Node newNode = new Node();
        newNode.data = data;
        newNode.next = null;
        if(head == null){
            head = newNode;
            tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }
    }
    public Node Reverse(Node node){
        Node prev = null;
        Node current = node;
        Node next = null;
        while(current != null){
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        node = prev;
        return node;
    }
    public void display(Node head){
        Node current = head;
        if(head == null){
            //System.out.println("List is empty");
            return;
        }
        while(current != null){
            System.out.print(current.data+" ");
            current = current.next;
        }
    }
    
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        List l = new List();
        String c;
        do{
            System.out.println("Enter the value:");
            int value = sc.nextInt();
            sc.nextLine();
            l.append(value);
            System.out.println("Do you want to add another node? Type Yes/No");
            c = sc.next();
        }while(c.equals("Yes")|| c.equals("yes"));
        System.out.print("The elements in the linked list are: ");
        l.display(head);
        System.out.print("\nThe elements in the reversed linked list are :");
        head = l.Reverse(head);
        l.display(head);
    }
    
    
    
    
}