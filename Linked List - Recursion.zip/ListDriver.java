import java.util.Scanner;

class ListDriver{
    static int a[]={};
    static int count;
    
    public static void occurence(int key, int i, int n){
        if(i==n){
            return;
        }
        if(a[i]==key)
        {
            count++;
        }
        occurence(key,i+1,n);
    }
    
    public static void main (String[] args) {
        Scanner sc =  new Scanner(System.in);
        System.out.print("Enter the size of the list: ");
        int n=sc.nextInt();
        if(n<=0){
            System.out.println("Invalid Input");
            return;
        }
        a = new int[n];
        for(int i=0;i<n;i++){
            a[i] = sc.nextInt();
        }
        System.out.println("Printing the list:");
        for (int i=0;i<n ;i++){
            System.out.print(a[i]+" ");
        } 
        System.out.print("\nEnter the key to find it's occurrence: ");
        int key=sc.nextInt();
        occurence(key,0,n);
        System.out.println("\n"+key+" occurs for "+count+" times.");
    }
}