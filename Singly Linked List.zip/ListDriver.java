import java.util.Scanner;


public class ListDriver{
    public static int palindrom(int n){
        for(int i=0,j=n-1;i<n/2;i++,j--){
            if(a[i]!=a[j])
                return 0;
        }
        return 1;
    }
    static int a[]={};
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        a=new int[n];
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.println(palindrom(n));
    }
}