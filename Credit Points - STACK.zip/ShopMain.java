import java.util.Scanner;
class ShopMain{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the no. of users:");
        int no_of_users = sc.nextInt();
        if(no_of_users==0 || no_of_users>1000 || no_of_users<0){
            System.out.println("Invalid no. of users");
        }
        else{
            int users_credit [] = new int[no_of_users];
            for (int i=0; i<no_of_users ;i++ ){
                System.out.print("Enter the credit points for user "+(i+1)+": ");
                users_credit[i] = sc.nextInt();
                if(users_credit[i]<0){
                    return;
                }
            } 
            System.out.print("Enter the no. of users to serve: ");
            int users_to_serve = sc.nextInt();
            if(users_to_serve<=0 || users_to_serve>no_of_users)
            {
                System.out.println("Invalid no. of users");
            }
            else{
                int value = no_of_users - users_to_serve;
                if(value==0){
                    System.out.println("0 users to serve");
                }
                else{
                    System.out.print("The unserved user's credit points are: ");
                    int j = users_to_serve;
                    while (j<no_of_users){
                        System.out.print(users_credit[j]+" ");
                        j++;
                    } 
                }
            }
        }
    }
}